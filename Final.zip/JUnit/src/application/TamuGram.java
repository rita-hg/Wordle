package application;
import java.util.ArrayList;
import java.util.List;

import javax.swing.text.AbstractDocument.Content;

import java.util.Collections;
import java.util.Comparator;

public class TamuGram {
    private List<Content> contentArray;

    public TamuGram() {
        this.contentArray = new ArrayList<>();
    }

    public void addContent(Content content) {
        if (contentArray.size() > 50) {
            throw new IllegalStateException("Content array length exceeds maximum limit.");
        }
        contentArray.add(content);
    }

    //with the given text, this function will go through the list of content to see if there is a matching caption or title with that text.
    //Then, this function will return the Content that has the matching text
    public Content findContentWithSameCaptionOrTitle(String text) throws Exception {
    	//TODO: Code this
    	if (contentArray.contains(text)) {
    		int currIndex = contentArray.indexOf(text);
    		return contentArray.get(currIndex);
    	}
//    	for (Content currContent : contentArray) {
//    		if (currContent.getClass().equals(checkingIfPost.getClass())) {
//    			if (currContent.) {
//    				
//    			}
//    		}
//    		else {
//    			
//    		}
//    	}
    	return null;
    	
    }

    //returns the number of posts in the list of content
    public int getPostCount() {
    	Post checkingIfPost = null;
    	
    	List<Content> postArray = new ArrayList<>();
    	for (Content currContent : contentArray) {
			if (currContent.getClass().equals(checkingIfPost.getClass())) {
		    	postArray.add(currContent);
			}
    	}
    	//TODO: Code this
    	return postArray.size();
        
    }

  //returns the number of stories in the list of content
    public int getStoryCount() {
    	Story checkingIfStory = null;
    	
    	List<Content> storyArray = new ArrayList<>();
    	for (Content currContent : contentArray) {
			if (currContent.getClass().equals(checkingIfStory.getClass())) {
		    	storyArray.add(currContent);
			}
    	}
    	//TODO: Code this
    	return storyArray.size();
    }

    //this function removes the content given in the parameter from the private member list of content
    //this function does not return anything but will change the private member list.
    public void removeContent(Content content) {
        contentArray.remove(content);
    }
    
    //This function will allow the List to be printed out. 
    //This will display all of the content regardless of the type of content. It won't return anything, but it will print in the console.
    public void displayAllContent() {
    	//TODO: Code this
    	displayAllPosts();
    	displayAllStories(); 
    }

    //This function will print only the posts in the List of content.
    //It won't return anything, but it will print the posts in the console.
    public void displayAllPosts() {
    	//TODO: Code this
    	Post checkingIfPost = null;
    	//Awesome view!, likes: 10, comments: 5, Location: New York, Tagged People: [John, James]
    	for (Content currContent : contentArray) {
			if (currContent.getClass().equals(checkingIfPost.getClass())) {
				System.out.print(((application.Post) currContent).getCaption());
				System.out.print(",likes: ");
				System.out.print(((application.Post) currContent).getCountLikes());
				System.out.print(",comments: ");
				System.out.print(((application.Post) currContent).getCountComments());
				System.out.print(",Location: ");
				System.out.print(((application.Post) currContent).getLocation());
				System.out.print(",Tagged People: ");
				for (String i: ((application.Content) currContent).getTagPeople()) {
					System.out.print(" ");
					System.out.print(i);
				}
			}
    	}
    }
    
    //This function will print only the stories in the List of content.
    //It won't return anything, but it will print the stories in the console.
    public void displayAllStories() {
    	//TODO: Code this
    	Story checkingIfStory= null;
    	//Awesome view!, likes: 10, comments: 5, Location: New York, Tagged People: [John, James]
    	for (Content currContent : contentArray) {
			if (currContent.getClass().equals(checkingIfStory.getClass())) {
				System.out.print(((application.Story) currContent).getCaption());
				System.out.print(",likes: ");
				System.out.print(((application.Story) currContent).getCountLikes());
				System.out.print(",comments: ");
				System.out.print(((application.Story) currContent).getCountComments());
				System.out.print(",Location: ");
				System.out.print(((application.Story) currContent).getLocation());
				System.out.print(",Tagged People: ");
				for (String i: ((application.Content) currContent).getTagPeople()) {
					System.out.print(" ");
					System.out.print(i);
				}
			}
    	}
        
    }
    
    //This function will return a Type that extends Content (it is a type of Content that will have the members and functions of Content, so either a story or a post)
    //The Type that is returned is the Content that has the most likes or seconds
    public <T extends Content> List<T> findTopNContent(List<T> contentList, int N) {
    	//TODO: code this
        
    }
    
    
    //This function will remove all the stories that have the same location
    //The function will not return anything, but it will change the actual list from the member. 
    public void removeSameLocationStories() {
    	//TODO: Code
    	List<String> usedPlaces = new ArrayList<String>();

    	Story checkingIfStory = null;   	
    	List<Content> storyArray = new ArrayList<>();
    	for (Content currContent : contentArray) {
			if (currContent.getClass().equals(checkingIfStory.getClass())) {
				if (usedPlaces.contains(((application.Content) currContent).getLocation())) {
			    	storyArray.add(currContent);
				}
			}
    	}
    	
    	Post checkingIfPost = null;
    	List<Content> postArray = new ArrayList<>();
    	for (Content currContent : contentArray) {
			if (usedPlaces.contains(((application.Content) currContent).getLocation())) {
		    	postArray.add(currContent);
			}
    	}
    	
    	this.contentArray.clear();
    	for (Content i: storyArray) {
    		contentArray.add(i);
    	}
    	for (Content j: postArray) {
    		contentArray.add(j);
    	}
       
    }
}
