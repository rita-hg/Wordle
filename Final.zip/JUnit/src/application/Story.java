package application;
import java.util.List;

public class Story extends Content {
    //private static final Exception Error = null;
    
    private String title;
    private int lengthSeconds;
    private boolean onlyCloseFriends;

    //initializes the Story class constructor.
    //The parameters for the initialization is title, the length of the story (seconds), only for close Friends?, location, the list of tagged people
    public Story(String title, int lengthSeconds, boolean onlyCloseFriends, String location, List<String> tagPeople) throws Exception {
    	//TODO: initialize the Story class constructor here, make sure you take of variables to be initialized 
    	// for this class and it's parent class
    	super(location, tagPeople);
    	this.title = title;
    	this.lengthSeconds = lengthSeconds;
    	this.onlyCloseFriends = onlyCloseFriends;
    	
        checkInappropriateness();
    }

    //returns the title of the story
    public String getTitle() {
    	// TODO: get title value
    	return title;
    }
    //changes the title of the story to title
    public void setTitle(String title) {
    	// TODO: set title value
    	this.title = title;
    }

    //returns the length of the story in seconds
    public int getLengthSeconds() {
    	// TODO: get lengthSeconds value
    	return lengthSeconds;
    }

    //returns the length of the story in seconds into the value of lengthSeconds
    public void setLengthSeconds(int lengthSeconds) {
    	// TODO: set lengthSeconds value
    	this.lengthSeconds = lengthSeconds;
    }

    //gets the onlyCloseFriends value
    public boolean isOnlyCloseFriends() {
    	// TODO: get onlyCloseFriends value
    	return onlyCloseFriends;
    }

    //sets the OnlyCloseFriends value
    public void setOnlyCloseFriends(boolean onlyCloseFriends) {
    	// TODO: set onlyCloseFriends value
    	this.onlyCloseFriends = onlyCloseFriends;
    }

    //This function goes through the words of the captions and titles to make sure that the phrase is appropriate. 
    //It overrides any other function that has this name to ensure it is for a story and not another object.
    @Override
    public void checkInappropriateness() throws Exception {
    	//TODO: Code this
    	String[] inappropriateWords = {"hate", "loser", "poor", "cheap", "disgusting", "mad"};
    	for (String i : inappropriateWords) {
    		if (i.equals(title)) {
    			throw new Error("This story is inappropriate and cannot be created.");
    		}
    	}

    }
}
