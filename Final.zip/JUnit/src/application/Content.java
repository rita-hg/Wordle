package application;

import java.util.List;

abstract class Content {
    private String location; //was private
    private List<String> tagPeople;

    //initializes the content when given a location and a list of tagged people
    public Content(String location, List<String> tagPeople) {
    	//TODO: initialize the Content class constructor here
    	this.location = location;
    	for (String i: tagPeople) {
    		this.tagPeople.add(i);
    	}
    }

    //returns the location
    public String getLocation() {
    	// TODO: get location value
    	return location;
    }

    //sets the location
    public void setLocation(String location) {
    	// TODO: set captain value
    	this.location = location;
    }

    //returns the list of tagged people
    public List<String> getTagPeople() {
    	// TODO: get tagPeople value
    	return tagPeople;
    }

    //sets the list of tagged people
    public void setTagPeople(List<String> tagPeople) {
    	// TODO: set tagPeople value
    	this.tagPeople.clear();
    	for (String i: tagPeople) {
    		this.tagPeople.add(i);
    	}
    }

    //checks if the post or story is appropriate. 
    //They are checked in their corresponding overridden functions
    public abstract void checkInappropriateness() throws Exception;
}
