package application;
import java.util.List;
import application.Content;

public class Post extends Content {
    private static final Exception Error = null;
	private String caption;
    private int countLikes;
    private int countComments;
	private Exception exception;

    //initializes the Post class constructor.
    //The parameters for the initialization is caption, the number of likes, number of comments, location, the list of tagged people
    public Post(String caption, int countLikes, int countComments, String location, List<String> tagPeople) throws Exception {
    	//TODO: initialize the Post class constructor here, make sure you take of variables to be initialized 
    	// for this class and it's parent class
    	super(location, tagPeople);
    	this.caption = caption;
    	this.countLikes = countLikes;
    	
    	
        checkInappropriateness();
    }

	//returns the caption of the post
    public String getCaption() {
    	// TODO: get captain value
    	return caption;
    }

    //sets the caption of the post
    public void setCaption(String caption) {
    	// TODO: set captain value
    	this.caption = caption;
    }

    //returns the number of likes
    public int getCountLikes() {
    	// TODO: get countLikes value
    	return countLikes;
    }

    //sets the number of likes
    public void setCountLikes(int countLikes) {
    	// TODO: set countLikes value
    	this.countLikes = countLikes;
    }

    //returns the number of comments
    public int getCountComments() {
    	// TODO: get countComments value
    	return countComments;
    }

    //sets the number of comments
    public void setCountComments(int countComments) {
    	// TODO: set countComments value
    	this.countComments = countComments;
    }

    //This function goes through the words of the captions and titles to make sure that the phrase is appropriate. 
    //It overrides any other function that has this name to ensure it is for a post and not another object.
    @Override
    public void checkInappropriateness() throws Exception {
    	//TODO: Code this
    	String[] inappropriateWords = {"hate", "loser", "poor", "cheap", "disgusting", "mad"};
    	for (String i : inappropriateWords) {
    		if (i.equalsIgnoreCase(caption)) {
    			throw new Error("This post is inappropriate and cannot be created.");
    		}
    	}

    }
}
