package application;
import java.util.List;
import java.util.ArrayList;

public class Driver {
    public static void main(String[] args) {
        // Create a new instance of TamuGram
        TamuGram tamuGram = new TamuGram();
        
        List<String> taggedUsers1 = new ArrayList<String>() {{
            add("John");
            add("James");
        }};

        List<String> taggedUsers2 = new ArrayList<String>() {{
            add("Sara");
            add("Silva");
            add("Stacy");
        }};

        List<String> taggedUsers3 = new ArrayList<String>() {{
            add("Ana");
            add("Adam");
            add("Andrew");
            add("Asher");
        }};
		Post post1 = new Post("Awesome view!", 10, 5, "New York", taggedUsers1);
		tamuGram.addContent(post1);

		Post post2 = new Post("Beautiful sunset", 15, 8, "London", taggedUsers2);
		tamuGram.addContent(post2);

		Post post3 = new Post("Cool city vibes", 9, 3, "Paris", taggedUsers3);
		tamuGram.addContent(post3);

		Story story1 = new Story("A day in Tokyo", 30, false, "Tokyo", taggedUsers1);
		tamuGram.addContent(story1);

		Story story2 = new Story("Scuba diving adventure", 45, true, "Sydney", taggedUsers2);
		tamuGram.addContent(story2);

		Story story3 = new Story("Relaxing beach day", 20, false, "Hawaii", taggedUsers3);
		tamuGram.addContent(story3);

		
		//Test Q-4:
		tamuGram.addContent(new Post("Disgusting view", 5, 2, "Alaska", taggedUsers2));
		//Should print "This post is inappropriate and cannot be created". You can comment the above line to test further content
		//since it will keep throwing exception otherwise
		
		tamuGram.addContent(new Story("A poor day", 45, true, "Toronto", taggedUsers2));
		//Should print "This story is inappropriate and cannot be created". You can comment the above line to test further content
		//since it will keep throwing exception otherwise
		
		tamuGram.addContent(new Story("A mAd day", 45, true, "Toronto", taggedUsers2));
		//Should not throw error
		
		
		//Test Q-5
		Content foundContent = tamuGram.findContentWithSameCaptionOrTitle("Scuba diving adventure");
        if (foundContent != null) {
            System.out.println("Found: " + foundContent.getLocation());
        } else {
            System.out.println("Content not found.");
        }
        //Should print Sydney
		
        Content foundContent1 = tamuGram.findContentWithSameCaptionOrTitle("Something random");
        if (foundContent1 != null) {
            System.out.println("Found: " + foundContent1.getLocation());
        } else {
            System.out.println("Content not found.");
        }
        //Should print Content not found.
        
        //Test Q-6
        
        System.out.println("Post Count: " + tamuGram.getPostCount());
        //Should print Post Count: 3
        
        System.out.println("Story Count: " + tamuGram.getStoryCount());
        //Should print Story Count: 4
        
        
        //Test Q-7
        // Display all posts
        System.out.println("All Posts:");
        tamuGram.displayAllPosts();
        //Post: Awesome view!, likes: 10, comments: 5, Location: New York, Tagged People: [John, James]
        //Post: Beautiful sunset, likes: 15, comments: 8, Location: London, Tagged People: [Sara, Silva, Stacy]
        //Post: Cool city vibes, likes: 9, comments: 3, Location: Paris, Tagged People: [Ana, Adam, Andrew, Asher]

        System.out.println("All Stories:");
        tamuGram.displayAllStories();
        //Story: A day in Tokyo, length: 30, Only close friends?: false, Location: Tokyo, Tagged People: [John, James]
        //Story: Scuba diving adventure, length: 45, Only close friends?: true, Location: Sydney, Tagged People: [Sara, Silva, Stacy]
        //Story: Relaxing beach day, length: 20, Only close friends?: false, Location: Hawaii, Tagged People: [Ana, Adam, Andrew, Asher]
        //Story: A mAd day, length: 45, Only close friends?: true, Location: Toronto, Tagged People: [Sara, Silva, Stacy]

        System.out.println("All Content:");
        tamuGram.displayAllContent();
        //Post: Awesome view!, likes: 10, comments: 5, Location: New York, Tagged People: [John, James]
        //Post: Beautiful sunset, likes: 15, comments: 8, Location: London, Tagged People: [Sara, Silva, Stacy]
        //Post: Cool city vibes, likes: 9, comments: 3, Location: Paris, Tagged People: [Ana, Adam, Andrew, Asher]
        //Story: A day in Tokyo, length: 30, Only close friends?: false, Location: Tokyo, Tagged People: [John, James]
        //Story: Scuba diving adventure, length: 45, Only close friends?: true, Location: Sydney, Tagged People: [Sara, Silva, Stacy]
        //Story: Relaxing beach day, length: 20, Only close friends?: false, Location: Hawaii, Tagged People: [Ana, Adam, Andrew, Asher]
        //Story: A mAd day, length: 45, Only close friends?: true, Location: Toronto, Tagged People: [Sara, Silva, Stacy]
        
        
        //Test Q-8
        List<Post> posts = new ArrayList<>();
        posts.add(new Post("Awesome view!", 10, 5, "New York", taggedUsers1));
        posts.add(new Post("Feeling happy today!", 88, 23, "Paris", taggedUsers1));
        posts.add(new Post("Graduated", 100, 50, "College Station", taggedUsers3));
        
        List<Post> topPosts = tamuGram.findTopNContent(posts, 5);
        if (topPosts != null) {
        	System.out.println("Top Posts:");
            for (Post post : topPosts) {
                System.out.println("- " + post.getCaption() + " (Likes: " + post.getCountLikes() + ")");
            }
        }
        //Exceeds total number of values present
        
        List<Post> topPosts1 = tamuGram.findTopNContent(posts, 2);
        if (topPosts1 != null) {
        	System.out.println("Top Posts:");
            for (Post post : topPosts1) {
                System.out.println("- " + post.getCaption() + " (Likes: " + post.getCountLikes() + ")");
            }
        }
        //Top Posts:
        //- Graduated (Likes: 100)
        //- Feeling happy today! (Likes: 88)
        
        
        //Test Q-9
        // Create a new instance of TamuGram
        TamuGram tamuGram1 = new TamuGram();
        tamuGram1.addContent(new Post("Awesome view!", 10, 5, "New York", taggedUsers1));
        tamuGram1.addContent(new Post("Feeling happy today!", 88, 23, "Paris", taggedUsers1));
        tamuGram1.addContent(new Post("Graduated", 100, 50, "College Station", taggedUsers3));
        Story story11 = new Story("A day in Tokyo", 30, false, "College Station", taggedUsers1);
        tamuGram1.addContent(story11);

        Story story22 = new Story("Scuba diving adventure", 45, true, "Sydney", taggedUsers2);
        tamuGram1.addContent(story22);
        System.out.println("Without modification");
        tamuGram1.displayAllContent();
        tamuGram1.removeSameLocationStories();
        System.out.println("After modification");
        tamuGram1.displayAllContent();
        //Without modification
        //Post: Awesome view!, likes: 10, comments: 5, Location: New YorkTagged People: [John, James]
        //Post: Feeling happy today!, likes: 88, comments: 23, Location: ParisTagged People: [John, James]
        //Post: Graduated, likes: 100, comments: 50, Location: College StationTagged People: [Ana, Adam, Andrew, Asher]
        //Story: A day in Tokyo, length: 30, Only close friends?: false, Location: College StationTagged People: [John, James]
        //Story: Scuba diving adventure, length: 45, Only close friends?: true, Location: SydneyTagged People: [Sara, Silva, Stacy]
        //After modification
        //Post: Awesome view!, likes: 10, comments: 5, Location: New YorkTagged People: [John, James]
        //Post: Feeling happy today!, likes: 88, comments: 23, Location: ParisTagged People: [John, James]
        //Post: Graduated, likes: 100, comments: 50, Location: College StationTagged People: [Ana, Adam, Andrew, Asher]
        
    }
}
